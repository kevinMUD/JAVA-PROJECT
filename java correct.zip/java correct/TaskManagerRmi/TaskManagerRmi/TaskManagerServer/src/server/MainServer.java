package server;

import java.rmi.registry.*;
import service.*;

public class MainServer {

    public static void main(String[] args) {
        try {
            //CREATING THE REGISTRY WITH PORT
            int port = 4019;
            Registry registry = LocateRegistry.createRegistry(port);
            TaskManagerInterface inter = (TaskManagerInterface) new TaskManagerService();
            //BINDING THE INTERFACE OBJECT TO THE REGISTRY
            registry.rebind("taskservice", inter);
            System.out.print("Server running is running please connection client ");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
