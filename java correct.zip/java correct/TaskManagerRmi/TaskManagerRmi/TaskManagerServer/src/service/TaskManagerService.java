package service;

import controllers.TaskManagerDao;
import java.rmi.RemoteException;
import java.rmi.server.*;
import java.util.*;
import model.*;

public class TaskManagerService extends UnicastRemoteObject implements TaskManagerInterface {

    public TaskManagerService() throws RemoteException {
        super();
    }

    TaskManagerDao dao = new TaskManagerDao();

    @Override
    public void saveEmployee(Employee emp) throws RemoteException {
        dao.saveEmployee(emp);
    }

    @Override
    public void saveTask(Tasks task) throws RemoteException {
        dao.saveTask(task);
    }

    @Override
    public List<Employee> getEmployees() throws RemoteException {
        List result = dao.getEmployees();
        return result;
    }

    @Override
    public Employee getEmployee(String id) throws RemoteException {
        Employee result = dao.getEmployee(id);
        return result;
    }

    @Override
    public List showTasks() throws RemoteException {
        List result = dao.showTasks();
        return result;
    }

    @Override
    public List showSpecTasks(String q) throws RemoteException {
        List result = dao.showSpecTasks(q);
        return result;
    }

}
