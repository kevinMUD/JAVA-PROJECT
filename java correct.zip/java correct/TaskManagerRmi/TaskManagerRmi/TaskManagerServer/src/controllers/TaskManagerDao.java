package controllers;

import java.util.*;
import model.*;
import org.hibernate.*;

public class TaskManagerDao {

    public void saveTask(Tasks task) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(task);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void saveEmployee(Employee emp) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(emp);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public List<Employee> getEmployees() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        List result = new ArrayList();
        try {
            tx = session.beginTransaction();
            result = session.createQuery("From Employee where manager = false").list();
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }

    public Employee getEmployee(String id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        Employee result = new Employee();
        try {
            tx = session.beginTransaction();
            String hql = "FROM Employee WHERE empid= :id";
            //CREATING A HIBERNATE QUERY AND ADD THE RESULT TO A LIST
            Query query = session.createQuery(hql);
            query.setParameter("id", id);
            List cResult = query.list();
            Iterator iterator = cResult.iterator();
            iterator.hasNext();
            result = (Employee) iterator.next();

            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }

    public List showTasks() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        List result = new ArrayList();
        try {
            tx = session.beginTransaction();
            String sql = "Select e.name, t.title, t.details, t.deadline from employee e, tasks t where e.empid = t.employee;";

            SQLQuery query = session.createSQLQuery(sql);
            query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

            result = query.list();

            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }

    public List showSpecTasks(String q) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        List result = new ArrayList();
        try {
            tx = session.beginTransaction();
            String sql = "Select t.details, t.deadline, t.title, e.name from tasks t, employee e where t.employee = e.empid AND t.employee = :cQuery";

            SQLQuery query = session.createSQLQuery(sql);
            query.setParameter("cQuery", q);
            query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);

            result = query.list();

            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }
}
