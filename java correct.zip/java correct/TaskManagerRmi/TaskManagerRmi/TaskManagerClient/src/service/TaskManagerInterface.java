package service;

import java.rmi.*;
import java.util.*;
import model.*;

public interface TaskManagerInterface extends Remote {

    public void saveEmployee(Employee emp) throws RemoteException;
    public void saveTask(Tasks task) throws RemoteException;

    public List<Employee> getEmployees() throws RemoteException;
    public Employee getEmployee(String id) throws RemoteException;
    public List showTasks() throws RemoteException;
    public List showSpecTasks(String q) throws RemoteException;
}
