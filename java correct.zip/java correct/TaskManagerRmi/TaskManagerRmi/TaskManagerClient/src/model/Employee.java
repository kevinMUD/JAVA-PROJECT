package model;

import java.io.Serializable;

public class Employee implements Serializable {
    private String empId;   
    private String name;
    private Boolean manager;

    public Employee() {
    }

    public Employee(String empId, String name, Boolean manager) {
        this.empId = empId;
        this.name = name;
        this.manager = manager;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getManager() {
        return manager;
    }

    public void setManager(Boolean manager) {
        this.manager = manager;
    }
    
}
