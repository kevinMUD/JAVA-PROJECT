package model;

import java.io.Serializable;
import java.util.Date;

public class Tasks implements Serializable {
    private int taskid;
    private String title;
    private String details;
    private Date deadline;
    private Employee employee;

    public Tasks(String title, String details, Date deadline, Employee employee) {
        this.title = title;
        this.details = details;
        this.deadline = deadline;
        this.employee = employee;
    }

    public Tasks() {
    }

    public int getTaskid() {
        return taskid;
    }

    public void setTaskid(int taskid) {
        this.taskid = taskid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
}
