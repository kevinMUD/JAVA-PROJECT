
package dao;

import java.util.List;
import model.Citizen;
import org.hibernate.*;


public class Citizendao {
    
    public String registercitizen(Citizen citizen){
    
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        citizen.setIsvaccinated(false);
        ss.save(citizen);
        tr.commit();
        ss.close();
        return "Data Saved successfully";
    
    }
   
     public String updatecitizen(Citizen citizen){
    
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        Citizen ctz = getcitizenbyid(citizen);
        if (ctz != null){
        ctz.setIsvaccinated(citizen.isIsvaccinated());
        ss.update(ctz);
        }
        tr.commit();
        ss.close();
        return "Data Updated successfully";
    
    }
     
      public String deletecitizen(Citizen citizen){
    
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        ss.delete(citizen);
        tr.commit();
        ss.close();
        return "Data Delete successfully";
    
    }
      
      public List<Citizen> allcitizen(){
      Session ss = HibernateUtil.getSessionFactory().openSession();
      List<Citizen> citizenlist =ss.createQuery("select cit from Citizen cit").list();
      ss.close();
      return citizenlist;
      }
      
      public Citizen getcitizenbyid(Citizen citizen){
      Session ss = HibernateUtil.getSessionFactory().openSession();
      Citizen cit = (Citizen) ss.get(Citizen.class, citizen.getCitizenid());
      ss.close();
      return cit;
      
      
      }
}
