package controller;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import service.citizenservice;
import service.vaccinationservice;



public class Server{
    
    private citizenservice citizenservice;
    private vaccinationservice vaccinationservice;
    
    public Server() throws RemoteException{
        this.citizenservice = new citizenservice();
        this.vaccinationservice = new vaccinationservice();
    
    }
    public static void main (String[] args) {
        try {
        System.setProperty("jva.rmi.server.hostname", "127.0.0.1");
        Registry registry = LocateRegistry.createRegistry(7900);
        registry.rebind("citizen", new citizenservice());
        registry.rebind("vaccination", new vaccinationservice());
       // registry.rebind("citizen", new Server().citizenservice);
       // registry.rebind("vaccination", new Server().vaccinationservice);
        System.out.println("Server is running...");
            
        }catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    
}
