package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


@Entity
public class Vaccination implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String vaccinationbrand;
    private Date vaccinationdate;
    private String citizen_fk;
    //@OneToOne
    //@JoinColumn(name = "citizenid")
    //private Citizen citizen;

    public Vaccination() {
    }

    public Vaccination(Integer id, String vaccinationbrand, Date vaccinationdate, String citizen_fk) {
        this.id = id;
        this.vaccinationbrand = vaccinationbrand;
        this.vaccinationdate = vaccinationdate;
        this.citizen_fk = citizen_fk;
    }

    public String getCitizen_fk() {
        return citizen_fk;
    }

    public void setCitizen_fk(String citizen_fk) {
        this.citizen_fk = citizen_fk;
    }

   

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    

    public String getVaccinationbrand() {
        return vaccinationbrand;
    }

    public void setVaccinationbrand(String vaccinationbrand) {
        this.vaccinationbrand = vaccinationbrand;
    }

    public Date getVaccinationdate() {
        return vaccinationdate;
    }

    public void setVaccinationdate(Date vaccinationdate) {
        this.vaccinationdate = vaccinationdate;
    }

   
    
    
    
}
