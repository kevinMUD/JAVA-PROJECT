/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.Citizendao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Citizen;

/**
 *
 * @author Hp
 */
public class citizenservice extends UnicastRemoteObject implements Citizeninterface{
    
    public citizenservice() throws RemoteException{
    super();
    } 
    
    public Citizendao dao = new Citizendao();

    @Override
    public String registercitizen(Citizen citizen) throws RemoteException {
       return dao.registercitizen(citizen);
         
    }

    @Override
    public String updatecitizen(Citizen citizen) throws RemoteException {
        return dao.updatecitizen(citizen);
    }

    @Override
    public String deletecitizen(Citizen citizen) throws RemoteException {
        return dao.deletecitizen(citizen);
    }

    @Override
    public List<Citizen> allcitizen() throws RemoteException {
        return dao.allcitizen();
    }

    @Override
    public Citizen getcitizenbyid(Citizen citizen) throws RemoteException {
        return dao.getcitizenbyid(citizen);
    }
    
}
