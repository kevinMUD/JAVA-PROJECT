
package service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import model.Citizen;


public interface Citizeninterface extends Remote {
    public String registercitizen(Citizen citizen) throws RemoteException;
    public String updatecitizen(Citizen citizen) throws RemoteException;
    public String deletecitizen(Citizen citizen) throws RemoteException;
    public List<Citizen> allcitizen() throws RemoteException;
    public Citizen getcitizenbyid(Citizen citizen) throws  RemoteException;
    
}
