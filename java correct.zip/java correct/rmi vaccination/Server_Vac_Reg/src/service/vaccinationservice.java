/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.Vaccinationdao;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Vaccination;

/**
 *
 * @author Hp
 */
public class vaccinationservice extends UnicastRemoteObject implements Vaccinationinterface{
    
    public vaccinationservice() throws RemoteException{
    super();
    } 
    
    
    public Vaccinationdao dao = new Vaccinationdao();

    @Override
    public String registervaccination(Vaccination vaccination) throws RemoteException {
        return dao.registerVaccination(vaccination);
    }

    @Override
    public String updatevaccination(Vaccination vaccination) throws RemoteException {
        return dao.updatevaccination(vaccination);
    }

    @Override
    public String deletevaccination(Vaccination vaccination) throws RemoteException {
        return dao.updatevaccination(vaccination);
    }

    @Override
    public List<Vaccination> allvaccination() throws RemoteException {
        return dao.allvaccinatedctz();
    }

    @Override
    public Vaccination getcitizenbyid(Vaccination vaccination) throws RemoteException {
        return dao.getvaccinationbyid(vaccination);
    }
    
}
