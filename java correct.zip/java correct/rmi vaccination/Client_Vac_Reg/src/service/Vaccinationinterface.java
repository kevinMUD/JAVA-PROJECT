
package service;

import java.rmi.RemoteException;
import java.util.List;
import model.Vaccination;

public interface Vaccinationinterface {
    
    public String registervaccination(Vaccination vaccination) throws RemoteException;
    public String updatevaccination(Vaccination vaccination) throws RemoteException;
    public String deletevaccination(Vaccination vaccination) throws RemoteException;
    public List<Vaccination> allvaccination() throws RemoteException;
    public Vaccination getcitizenbyid(Vaccination vaccination) throws  RemoteException;
    
    
}
