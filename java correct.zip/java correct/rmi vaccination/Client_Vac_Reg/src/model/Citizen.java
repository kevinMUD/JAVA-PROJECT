package model;

import java.io.Serializable;

public class Citizen implements Serializable{
    private String citizenid;
    private String fullnames;
    private String phone;
    private boolean isvaccinated;

    public Citizen() {
    }

    public Citizen(String citizenid, String fullnames, String phone) {
        this.citizenid = citizenid;
        this.fullnames = fullnames;
        this.phone = phone;
    }

    public boolean isIsvaccinated() {
        return isvaccinated;
    }

    public void setIsvaccinated(boolean isvaccinated) {
        this.isvaccinated = isvaccinated;
    }

    public Citizen(String citizenid) {
        this.citizenid = citizenid;
    }

    public String getCitizenid() {
        return citizenid;
    }

    public void setCitizenid(String citizenid) {
        this.citizenid = citizenid;
    }

    public String getFullnames() {
        return fullnames;
    }

    public void setFullnames(String fullnames) {
        this.fullnames = fullnames;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    
    
}
