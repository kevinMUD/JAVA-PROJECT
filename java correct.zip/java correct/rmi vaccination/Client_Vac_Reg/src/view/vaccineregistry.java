package view;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Citizen;
import model.Vaccination;
import service.Citizeninterface;
import service.Vaccinationinterface;


public class vaccineregistry extends javax.swing.JFrame {

  private DefaultTableModel model = new DefaultTableModel();
  private DefaultTableModel mode = new DefaultTableModel();
    public vaccineregistry() { 
        initComponents();
        addvaccinebrand();
        addcitizenid(); 
        addvaccinecolumn();
        addunvaccinecolumn();
        addvaccinatedpipo();
        addunvaccinatedpipo();
       
    }
    private void addvaccinecolumn(){
    model.addColumn("citizen ID");
    model.addColumn("citizen name");
    model.addColumn("phone");
    model.addColumn("vaccine brand");
    model.addColumn("vaccine date");
    vactabe.setModel(model);
    }
    
     private void addunvaccinecolumn(){
    mode.addColumn("citizen ID");
    mode.addColumn("citizen name");
    mode.addColumn("phone");
    mode.addColumn("vaccine brand");
    mode.addColumn("vaccine date");
    unvactable.setModel(mode);
    }
     
     private void addvaccinatedpipo(){
         try {
            Registry registry = LocateRegistry.getRegistry(7900);
            Vaccinationinterface intrfc = (Vaccinationinterface) registry.lookup("vaccination");
            Citizeninterface intrf=(Citizeninterface) registry.lookup("citizen");
            List<Vaccination> vaccinationlist= intrfc.allvaccination();
            Iterator iterator = vaccinationlist.iterator();
            while(iterator.hasNext()){
            Vaccination vacc = (Vaccination) iterator.next();
            Citizen cit = new  Citizen(vacc.getCitizen_fk()); 
            Citizen ctz = intrf.getcitizenbyid(cit);
            model.addRow (new Object[]{
            ctz.getCitizenid(),
            ctz.getFullnames(),
            ctz.getPhone(),
            vacc.getVaccinationbrand(),
            vacc.getVaccinationdate()
            
            }); 
            
            }
            vactabe.setModel(model);
         } catch (Exception ex) {
             ex.printStackTrace();
         }
     }
     
     private void addunvaccinatedpipo(){
         try {
              Registry registry = LocateRegistry.getRegistry(7900);
            //Vaccinationinterface intrfc = (Vaccinationinterface) registry.lookup("vaccination");
            Citizeninterface intrf=(Citizeninterface) registry.lookup("citizen");
            List<Citizen> citizenlist= intrf.allcitizen();
             Iterator iterator = citizenlist.iterator();
            while(iterator.hasNext()){
            Citizen ctz =(Citizen) iterator.next();
            if(ctz.isIsvaccinated() == false){
            mode.addRow(new Object[]{
            ctz.getCitizenid(),
            ctz.getFullnames(),
            ctz.getPhone(),
            
            });
            }
            }
            unvactable.setModel(mode);
         } catch (Exception ex) {
             ex.printStackTrace();
         }
     }

    private void addvaccinebrand(){
    vaccinecombo.removeAllItems();
    vaccinecombo.addItem(Vaccinebrand.Pfizer.toString());
    vaccinecombo.addItem(Vaccinebrand.Moderna.toString());
    vaccinecombo.addItem(Vaccinebrand.AstraZeneca.toString());
    }
    
    private void addcitizenid(){
    citizencombo.removeAllItems();
        try {
            Registry registry = LocateRegistry.getRegistry("127.0.0.1",7900);
            Citizeninterface intrf = (Citizeninterface) registry.lookup("citizen");
            List<Citizen> citizenlist = intrf.allcitizen();
            Iterator iterator = citizenlist.iterator();
            
            while(iterator.hasNext()){
            Citizen ctz = (Citizen) iterator.next();
            if(ctz.isIsvaccinated() == false){
            citizencombo.addItem(ctz.getCitizenid());
            }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
   
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        citizencombo = new javax.swing.JComboBox<>();
        vaccinecombo = new javax.swing.JComboBox<>();
        vaccinedate = new com.toedter.calendar.JDateChooser();
        savevaccine = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        unvactable = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        vactabe = new javax.swing.JTable();
        VACBTN = new javax.swing.JButton();
        UNVACBTN = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Citizen ID");

        jLabel2.setText("Vaccine Brand");

        jLabel3.setText("VACCINATION REGISTRY");

        jLabel4.setText("Vaccination Date");

        savevaccine.setText("SAVE");
        savevaccine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savevaccineActionPerformed(evt);
            }
        });

        jLabel5.setText("UNVACCINATED CITIZEN");

        unvactable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Names", "Phone", "Vac Brand", "Vac Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane3.setViewportView(unvactable);

        jLabel6.setText("VACCINATED CITIZEN");

        vactabe.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Names", "Phone", "Vac Brand", "Vac Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        vactabe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                vactabeMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(vactabe);

        VACBTN.setText("PRINT VACCINATED");
        VACBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VACBTNActionPerformed(evt);
            }
        });

        UNVACBTN.setText("PRINT UNVACCINATED");
        UNVACBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UNVACBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(179, 179, 179)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(VACBTN))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel1))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(65, 65, 65)
                                .addComponent(UNVACBTN))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(vaccinecombo, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(citizencombo, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(vaccinedate, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addComponent(savevaccine)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 443, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(204, 204, 204))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(210, 210, 210))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel3)
                .addGap(1, 1, 1)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(citizencombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(vaccinecombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(vaccinedate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(38, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(savevaccine)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(VACBTN)
                            .addComponent(UNVACBTN))
                        .addGap(51, 51, 51))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void savevaccineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savevaccineActionPerformed
        try {
             Registry registry = LocateRegistry.getRegistry("127.0.0.1",7900);
             Vaccinationinterface intrfc = (Vaccinationinterface) registry.lookup("vaccination");
             Citizeninterface intrf = (Citizeninterface) registry.lookup("citizen");
             Vaccination vac = new Vaccination();
             vac.setCitizen_fk(citizencombo.getSelectedItem().toString());
             vac.setVaccinationbrand(vaccinecombo.getSelectedItem().toString());
             //SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
             //Date date = new Date(sdf.format(vaccinedate.getDate()));
             vac.setVaccinationdate(vaccinedate.getDate());
             intrfc.registervaccination(vac);
             
             Citizen ctz = new Citizen();
             ctz.setCitizenid(citizencombo.getSelectedItem().toString());
             ctz.setIsvaccinated(true);
             String feedback= intrf.updatecitizen(ctz);
             JOptionPane.showMessageDialog(this,"citizen has been vaccinated with id:"+vac.getCitizen_fk());
             addcitizenid();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_savevaccineActionPerformed

    private void VACBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VACBTNActionPerformed
        try {
            vactabe.print();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_VACBTNActionPerformed

    private void UNVACBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UNVACBTNActionPerformed
        try{
            unvactable.print();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_UNVACBTNActionPerformed

    private void vactabeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vactabeMouseClicked
 try {            
            DefaultTableModel model = (DefaultTableModel) vactabe.getModel();
            int selectedRow = vactabe.getSelectedRow();
            citizencombo.setSelectedItem(model.getValueAt(selectedRow, 0).toString());
            vaccinecombo.setSelectedItem(Vaccinebrand.valueOf(model.getValueAt(selectedRow, 1).toString()));
            vaccinedate.setDateFormatString(model.getValueAt(selectedRow, 2).toString());
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }       
    }//GEN-LAST:event_vactabeMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(vaccineregistry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(vaccineregistry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(vaccineregistry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(vaccineregistry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new vaccineregistry().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton UNVACBTN;
    private javax.swing.JButton VACBTN;
    private javax.swing.JComboBox<String> citizencombo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton savevaccine;
    private javax.swing.JTable unvactable;
    private javax.swing.JComboBox<String> vaccinecombo;
    private com.toedter.calendar.JDateChooser vaccinedate;
    private javax.swing.JTable vactabe;
    // End of variables declaration//GEN-END:variables
}


