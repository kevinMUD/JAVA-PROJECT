package view;


public enum Vaccinebrand {
    Pfizer,
    AstraZeneca,
    Moderna,
    
}
