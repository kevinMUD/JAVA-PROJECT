package controllers;

import java.util.*;
import model.*;
import org.hibernate.*;

public class DivLicenseDao {

    public void saveCitizen(Citizen cit) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(cit);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void saveLicense(License lic) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(lic);
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public Citizen getCitizen(String id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        Citizen result = new Citizen();
        try {
            tx = session.beginTransaction();
            String hql = "FROM Citizen WHERE citizenid= :id";
            //CREATING A HIBERNATE QUERY AND ADD THE RESULT TO A LIST
            Query query = session.createQuery(hql);
            query.setParameter("id", id);
            List cResult = query.list();
            Iterator iterator = cResult.iterator();
            iterator.hasNext();
            result = (Citizen) iterator.next();

            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }

    public List showLicensed() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        List result = new ArrayList();
        try {
            tx = session.beginTransaction();
            String sql;

            sql = "Select name,citizenid, phone, citid, category, dateissued from citizen c, license l where c.citizenid = l.citid";

            SQLQuery query = session.createSQLQuery(sql);
            query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
            result = query.list();

            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }

    public List showUnlicensed() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        List result = new ArrayList();
        try {
            tx = session.beginTransaction();
            String sql;

            sql = "Select name,citizenid, phone, citid, category, dateissued from citizen c left join license l on c.citizenid = l.citid where l.citid is null;";

            SQLQuery query = session.createSQLQuery(sql);
            query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
            result = query.list();

            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }

    public List<Citizen> showCitizens() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        List result = new ArrayList();
        try {
            tx = session.beginTransaction();
            result = session.createQuery("FROM Citizen").list();

            tx.commit();
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return result;
    }
}
