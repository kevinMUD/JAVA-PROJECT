package service;

import controllers.DivLicenseDao;
import java.rmi.RemoteException;
import java.rmi.server.*;
import java.util.List;
import model.Citizen;
import model.License;

public class DivLicenseService extends UnicastRemoteObject implements DivLicenseInterface {

    public DivLicenseService() throws RemoteException {
        super();
    }

    DivLicenseDao dao = new DivLicenseDao();

    @Override
    public void saveCitizen(Citizen cit) throws RemoteException {
        dao.saveCitizen(cit);
    }

    @Override
    public void saveLicense(License lic) throws RemoteException {
        dao.saveLicense(lic);
    }

    @Override
    public Citizen getCitizen(String id) throws RemoteException {
        Citizen result = dao.getCitizen(id);
        return result;
    }

    @Override
    public List showLicensed() throws RemoteException {
        List result = dao.showLicensed();
        return result;
    }

    @Override
    public List showUnlicensed() throws RemoteException {
        List result = dao.showUnlicensed();
        return result;
    }

    @Override
    public List<Citizen> showCitizens() throws RemoteException {
        List result = dao.showCitizens();
        return result;
    }

}
