package server;

import java.rmi.registry.*;
import service.*;

public class MainServer {

    public static void main(String[] args) {
        try {
            //CREATING THE REGISTRY WITH PORT
            int port = 2022;
            Registry registry = LocateRegistry.createRegistry(port);
            DivLicenseInterface interf = (DivLicenseInterface) new DivLicenseService();
            //BINDING THE INTERFACE OBJECT TO THE REGISTRY
            registry.rebind("divlicense", interf);
            System.out.print("Server running on port: " + port);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
