package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name= "license")
public class License implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String category;
    @Temporal(TemporalType.DATE)
    private Date dateissued;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "citid")
    private Citizen citid;

    public License() {
    }

    public License(String category, Date dateissued, Citizen citid) {
        this.category = category;
        this.dateissued = dateissued;
        this.citid = citid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Date getDateissued() {
        return dateissued;
    }

    public void setDateissued(Date dateissued) {
        this.dateissued = dateissued;
    }

    public Citizen getCitid() {
        return citid;
    }

    public void setCitid(Citizen citid) {
        this.citid = citid;
    }   
}
