package model;

import java.io.Serializable;
import java.util.Date;

public class License implements Serializable {
    private int id;
    private String category;
    private Date dateissued;
    private Citizen citid;

    public License() {
    }

    public License(String category, Date dateissued, Citizen citid) {
        this.category = category;
        this.dateissued = dateissued;
        this.citid = citid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Date getDateissued() {
        return dateissued;
    }

    public void setDateissued(Date dateissued) {
        this.dateissued = dateissued;
    }

    public Citizen getCitid() {
        return citid;
    }

    public void setCitid(Citizen citid) {
        this.citid = citid;
    }   
}
