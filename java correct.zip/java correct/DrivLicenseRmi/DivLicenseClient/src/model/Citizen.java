package model;

import java.io.Serializable;

public class Citizen implements Serializable {
    private String citizenid;
    private String name;
    private String phone;

    public Citizen() {
    }

    public Citizen(String citizenid, String name, String phone) {
        this.citizenid = citizenid;
        this.name = name;
        this.phone = phone;
    }

    public String getCitizenid() {
        return citizenid;
    }

    public void setCitizenid(String citizenid) {
        this.citizenid = citizenid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    
}
