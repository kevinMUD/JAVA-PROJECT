package service;

import java.rmi.*;
import java.util.List;
import model.*;

public interface DivLicenseInterface extends Remote{
    public void saveCitizen(Citizen cit) throws RemoteException;
    public void saveLicense(License lic) throws RemoteException;
    
    public Citizen getCitizen(String id) throws RemoteException;
    public List<Citizen> showCitizens() throws RemoteException;
    public List showLicensed() throws RemoteException;
    public List showUnlicensed() throws RemoteException;
}
