/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.*;

/**
 *
 * @author hp
 */
@Entity
public class BookTransaction implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int TransId;
    private Client client;
    private Book book;
    private LocalDate transactionDate;
    private LocalDate returnDate;
    private TransactionType type;
    @Transient
    private static final long serialVersionUID = -2745550691178689811L;

    public BookTransaction() {
    }

    
    public BookTransaction(Client client, Book book, LocalDate transactionDate, LocalDate returnDate, TransactionType type) {
        this.client = client;
        this.book = book;
        this.transactionDate = transactionDate;
        this.returnDate = returnDate;
        this.type = type;
    }

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public LocalDate getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDate transactionDate) {
        this.transactionDate = transactionDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    } 

    public int getTransId() {
        return TransId;
    }

    public void setTransId(int TransId) {
        this.TransId = TransId;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }
    
}

