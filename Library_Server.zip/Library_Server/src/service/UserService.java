/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import DAO.UserDAO;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import model.User;

/**
 *
 * @author hp
 */
public class UserService extends UnicastRemoteObject implements UserServiceInterface {

    public UserService() throws RemoteException {
        super();
    }

    
    @Override
    public boolean saveUser(User user) throws RemoteException {
        UserDAO.saveUser(user);
        return true;
    }

    @Override
    public User getUser(String id) throws RemoteException {
        User user = UserDAO.getUser(id);
        return user;
    }
    
}
