/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import model.Client;

/**
 *
 * @author hp
 */
public interface ClientServiceInterface extends Remote {
    public boolean saveClient(Client client) throws RemoteException;
    public Client getClient(String column, String value) throws RemoteException;
    public List<Client> allClients() throws RemoteException;
}
