/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import DAO.TransactionDAO;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.BookTransaction;

/**
 *
 * @author hp
 */
public class TransactionService extends UnicastRemoteObject implements TransactionServiceInterface {

    public TransactionService() throws RemoteException {
        super();
    }

    @Override
    public boolean saveTransaction(BookTransaction trans) throws RemoteException {
        TransactionDAO.saveTransaction(trans);
        return true;
    }

    @Override
    public BookTransaction getTransaction(String column, String value) throws RemoteException {
        BookTransaction transac = TransactionDAO.getTransaction(column, value);
        return transac;
    }

    @Override
    public List<BookTransaction> allTransaction() throws RemoteException {
        List<BookTransaction> transacs = TransactionDAO.allTransaction();
        return transacs;
    }
    
}
