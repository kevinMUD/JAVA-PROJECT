/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import DAO.BookDAO;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Book;

/**
 *
 * @author hp
 */
public class BookService extends UnicastRemoteObject implements BookServiceInterface{

    public BookService() throws RemoteException {
        super();
    }
    
    
    @Override
    public boolean saveBook(Book book) throws RemoteException {
        BookDAO.saveBook(book);
        return true;
    }

    @Override
    public Book getBook(String column, String value) throws RemoteException {
        Book book = BookDAO.getBook(column, value);
        return book;
    }

    @Override
    public List<Book> allBooks() throws RemoteException {
        List<Book> books = BookDAO.allBooks();
        return books;
    }
    
}
