/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.List;
import model.BookCategory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author hp
 */
public class CategoryDAO {
    static Session session = null;
    public static void saveCategory(BookCategory cat)
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(cat);
        tx.commit();
        session.close();
    }
    public static List<BookCategory> allCategory() 
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Query hql = session.createQuery("from BookCategory");
        List<BookCategory> categories = hql.list();
        tx.commit();
        session.close();
        return categories;
    }
}
