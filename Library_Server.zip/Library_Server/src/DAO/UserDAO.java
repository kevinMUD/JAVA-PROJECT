/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import model.User;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author hp
 */
public class UserDAO {
    static Session session = null;
    
    public static boolean saveUser(User user){
        boolean saved = false;
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(user);
        saved = true;
        tx.commit();
        session.close();
        return saved;
    }
    public static User getUser(String id){
        User user = null;
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        String hql = "from User where user_id='"+id+"'";
        Query q = session.createQuery(hql);
        user = (User)q.uniqueResult();
        tx.commit();
        session.close();
        return user;
    }
}
