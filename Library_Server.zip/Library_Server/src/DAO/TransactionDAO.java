/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.List;
import model.BookTransaction;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author hp
 */
public class TransactionDAO {
    static Session session = null;
    public static void saveTransaction(BookTransaction trans)
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(trans);
        tx.commit();
        session.close();
    }
    public static BookTransaction getTransaction(String column, String value)
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Query hql = session.createQuery("from BookTransaction where "+column+"="+"'"+value+"'");
        BookTransaction transaction =  (BookTransaction)hql.uniqueResult();
        tx.commit();
        session.close();
        return transaction;
    }
    public static List<BookTransaction> allTransaction()
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Query hql = session.createQuery("from BookTransaction");
        List<BookTransaction> transactions =  hql.list();
        tx.commit();
        session.close();
        return transactions;
    }
}
