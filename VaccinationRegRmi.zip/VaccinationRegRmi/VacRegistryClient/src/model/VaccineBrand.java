package model;

public enum VaccineBrand {
    Pfizer, Moderna, AstraZeneca
}
