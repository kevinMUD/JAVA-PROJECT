package helpers;

import frames.*;
import java.util.*;
import org.hibernate.*;

public class DuplicatesCheck {

    public int checkDuplicates(String id, String type) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        String hql = "From " + type + " where id= :id";

        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        List result = query.list();

        return result.size();
    }
}
