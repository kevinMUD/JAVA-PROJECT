package frames;

import org.hibernate.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import mapping.*;
import comboBox.*;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.poi.xssf.usermodel.*;
import org.hibernate.criterion.MatchMode;

public class OperationsPage extends javax.swing.JInternalFrame {

    public OperationsPage() {
        initComponents();
        showClients();
        showBooks();
        showTableData();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        clientField = new javax.swing.JComboBox<>();
        bookField = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        typeField = new javax.swing.JComboBox<>();
        saveTransBtn = new javax.swing.JButton();
        retDate = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        transTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        criteriaField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        searchBtn = new javax.swing.JButton();
        searchDate = new com.toedter.calendar.JDateChooser();
        exportExcelBtn = new javax.swing.JButton();
        exportPdfBtn = new javax.swing.JButton();
        searchDateBtn = new javax.swing.JButton();
        refreshBtn = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Book Transactions");

        jPanel1.setPreferredSize(new java.awt.Dimension(1046, 740));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Add new transaction", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Open Sans", 1, 12))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel2.setText("Client Names");

        clientField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N

        bookField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel3.setText("Book title");

        jLabel4.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel4.setText("Transaction Type");

        typeField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        typeField.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose", "BORROW", "RETURN" }));
        typeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeFieldActionPerformed(evt);
            }
        });

        saveTransBtn.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        saveTransBtn.setText("Save Transactions");
        saveTransBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveTransBtnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel6.setText("Return Date");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(clientField, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(24, 24, 24)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(bookField, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(typeField, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(58, 58, 58)
                                .addComponent(retDate, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(saveTransBtn)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(clientField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(bookField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(typeField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel6))
                    .addComponent(retDate, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addComponent(saveTransBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        transTable.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        transTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No.", "Client Id", "Client Names", "Book", "Book Categ.", "Type", "Trans. Date", "Ret. Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(transTable);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Table Operations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Open Sans", 1, 12))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel1.setText("Search by Criteria");

        criteriaField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel5.setText("Search by Date");

        searchBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/search-icon.png"))); // NOI18N
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });

        exportExcelBtn.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        exportExcelBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Microsoft-Excel-2013-icon.png"))); // NOI18N
        exportExcelBtn.setText("Export xlsx");
        exportExcelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportExcelBtnActionPerformed(evt);
            }
        });

        exportPdfBtn.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        exportPdfBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Apps-Pdf-icon.png"))); // NOI18N
        exportPdfBtn.setText("Export PDF");
        exportPdfBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportPdfBtnActionPerformed(evt);
            }
        });

        searchDateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/event-search-icon.png"))); // NOI18N
        searchDateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchDateBtnActionPerformed(evt);
            }
        });

        refreshBtn.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        refreshBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/reload-icon.png"))); // NOI18N
        refreshBtn.setText("Refresh Table");
        refreshBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(criteriaField)
                    .addComponent(searchDate, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchBtn)
                    .addComponent(searchDateBtn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(exportPdfBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(exportExcelBtn)
                .addGap(18, 18, 18)
                .addComponent(refreshBtn)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(criteriaField, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel5))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(searchDate, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchDateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exportPdfBtn)
                    .addComponent(exportExcelBtn)
                    .addComponent(refreshBtn))
                .addGap(45, 45, 45))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(100, 100, 100)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 938, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(82, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1046, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 711, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//GET ALL CLIENTS AND ADD THEM TO CLIENT COMBOBOX

    public void showClients() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            List result = session.createQuery("FROM Clients").list();

            CategItem dItem = new CategItem("DEFAULT", "Choose");
            clientField.addItem(dItem);

            for (Iterator iterator = result.iterator(); iterator.hasNext();) {
                Clients client = (Clients) iterator.next();
                String fname = client.getFirstname();
                String lname = client.getLastname();
                String id = client.getRegid();
                String elt = lname + " " + fname;
                CategItem cItem = new CategItem(id, elt);
                clientField.addItem(cItem);
            }
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    //GET ALL BOOKS AND ADD THEM TO CLIENT COMBOBOX
    public void showBooks() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            List result = session.createQuery("FROM Books").list();
            CategItem dItem = new CategItem("DEFAULT", "Choose");
            bookField.addItem(dItem);

            for (Iterator iterator = result.iterator(); iterator.hasNext();) {
                Books book = (Books) iterator.next();
                String id = book.getBookid();
                String name = book.getTitle();
                CategItem cItem = new CategItem(id, name);
                bookField.addItem(cItem);
            }
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    //POPULATE TRANSACTIONS TABLE
    public void showTableData() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            String sql = "SELECT c.regid, c.firstname, c.lastname, b.title, g.name , t.type, t.transdate, t.retdate FROM clients c, books b, book_category g, transactions t WHERE c.regid = t.client AND b.category = g.code AND b.bookid = t.book;";
            SQLQuery query = session.createSQLQuery(sql);
            query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
            List data = query.list();

            DefaultTableModel model = (DefaultTableModel) transTable.getModel();
            Object[] tblRow = new Object[8];
            int rowNum = 0;
            for (Object object : data) {
                Map row = (Map) object;
                rowNum += 1;
                tblRow[0] = rowNum;
                tblRow[1] = row.get("regid");
                String fname = row.get("firstname").toString();
                String lname = row.get("lastname").toString();
                tblRow[2] = lname + " " + fname;
                tblRow[3] = row.get("title");
                tblRow[4] = row.get("name");
                tblRow[5] = row.get("type");
                tblRow[6] = row.get("transdate");
                if (row.get("retdate") == null) {
                    tblRow[7] = "-";
                } else {
                    tblRow[7] = row.get("retdate");
                }

                model.addRow(tblRow);
            }

            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    //ADDING A NEW BOOK TRANSACTION
    public void saveBookTransaction() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            Transactions trans = new Transactions();

            //GETTING THE SELECTED CLIENT
            String hql = "FROM Clients WHERE regid= :cId";
            CategItem item = (CategItem) clientField.getSelectedItem();
            String id = item.id;

            Query query = session.createQuery(hql);
            query.setParameter("cId", id);
            List result = query.list();

            Iterator iterator = result.iterator();
            iterator.hasNext();
            Clients cResult = (Clients) iterator.next();

            //GETTING THE SELECTED BOOK
            String hql2 = "FROM Books WHERE bookid= :bId";
            CategItem item2 = (CategItem) bookField.getSelectedItem();
            String id2 = item2.id;
            Query query2 = session.createQuery(hql2);
            query2.setParameter("bId", id2);
            List result2 = query2.list();

            Iterator iterator2 = result2.iterator();
            iterator2.hasNext();
            Books bResult = (Books) iterator2.next();

            //PASSING DATA TO THE MAPPING FILE
            trans.setClient(cResult);
            trans.setBook(bResult);
            String type = typeField.getSelectedItem().toString();
            trans.setType(TransactionType.valueOf(type));

            //GET CURRENT DATE
            Date currentDt = new Date();
            trans.setTransdate(currentDt);
            if (retDate.getDate() != null) {
                trans.setRetdate(retDate.getDate());
            }
            session.save(trans);
            tx.commit();

            //DISPLAY SUCCESS MSG
            JOptionPane.showMessageDialog(null, "Saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

            //UPDATE TABLE
            DefaultTableModel model = (DefaultTableModel) transTable.getModel();
            model.setRowCount(0);
            showTableData();

            //CLEAR FORM
            typeField.setSelectedItem("Choose");
            clientField.removeAllItems();
            showClients();
            bookField.removeAllItems();
            showBooks();
            retDate.setDate(null);

        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    //REFRESH TABLE
    public void refreshTable() {
        DefaultTableModel model = (DefaultTableModel) transTable.getModel();
        model.setRowCount(0);
        showTableData();
    }

    //SEARCH BOOK TRANSACTION
    public void searchTransaction(String qCriteria, Date qDate, String type) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            String sql;
            if (type.equals("criteria")) {
                sql = "SELECT c.firstname, c.lastname, b.title, g.name, t.client, t.type, t.transdate, t.retdate FROM clients c, books b, book_category g, transactions t WHERE c.regid = t.client AND b.category = g.code AND b.bookid = t.book AND"
                        + "(t.client like CONCAT('%',:cQuery,'%') OR c.firstname like CONCAT('%',:cQuery,'%') OR c.lastname LIKE CONCAT('%',:cQuery,'%') OR b.title like CONCAT('%',:cQuery,'%') OR g.name like CONCAT('%',:cQuery,'%'))";
            } else {
                sql = "SELECT c.firstname, c.lastname, b.title, g.name, t.client, t.type, t.transdate, t.retdate FROM clients c, books b, book_category g, transactions t WHERE c.regid = t.client AND b.category = g.code AND b.bookid = t.book AND (t.transdate= :dQuery OR t.retdate = :dQuery);";
            }

            SQLQuery query = session.createSQLQuery(sql);

            if (type.equals("criteria")) {
                query.setParameter("cQuery", MatchMode.ANYWHERE.toMatchString(qCriteria));
            } else {
                query.setParameter("dQuery", qDate);
            }

            query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
            List data = query.list();

            DefaultTableModel model = (DefaultTableModel) transTable.getModel();
            Object[] tblRow = new Object[8];

            int rowNum = 0;
            if (data.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No results returned from the search query!", "No data", JOptionPane.INFORMATION_MESSAGE);
                model.setRowCount(0);
            } else {
                JOptionPane.showMessageDialog(null, "Search Results found!", "No data", JOptionPane.INFORMATION_MESSAGE);
                model.setRowCount(0);
                for (Object object : data) {
                    Map row = (Map) object;
                    rowNum += 1;
                    tblRow[0] = rowNum;
                    tblRow[1] = row.get("client");
                    String fname = row.get("firstname").toString();
                    String lname = row.get("lastname").toString();
                    tblRow[2] = lname + " " + fname;
                    tblRow[3] = row.get("title");
                    tblRow[4] = row.get("name");
                    tblRow[5] = row.get("type");
                    tblRow[6] = row.get("transdate");
                    if (row.get("retdate") == null) {
                        tblRow[7] = "-";
                    } else {
                        tblRow[7] = row.get("retdate");
                    }

                    model.addRow(tblRow);
                }
            }

            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    private void typeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeFieldActionPerformed
        //TOGGLE DISABLING RETURN DATE FIELD
        String type = typeField.getSelectedItem().toString();
        if (type.equals("BORROW")) {
            retDate.setEnabled(true);
        } else {
            retDate.setEnabled(false);
        }
    }//GEN-LAST:event_typeFieldActionPerformed

    private void saveTransBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveTransBtnActionPerformed
        //VALIDATE FORM FIELDS
        Date currentDt = new Date();
        long cDt = currentDt.getTime();
        if (clientField.getSelectedItem().toString().equals("Choose")
                || bookField.getSelectedItem().toString().equals("Choose")
                || typeField.getSelectedItem().toString().equals("Choose")
                || (typeField.getSelectedItem().toString().equals("BORROW")
                && retDate.getDate() == null)) {
            JOptionPane.showMessageDialog(null, "Please fill all fields!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else if (typeField.getSelectedItem().toString().equals("BORROW")
                && retDate.getDate() != null
                && retDate.getDate().getTime() < cDt) {
            JOptionPane.showMessageDialog(null, "Return date must be later than today!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else {
            saveBookTransaction();
        }
    }//GEN-LAST:event_saveTransBtnActionPerformed

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        if (criteriaField.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Search field can't be empty!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else {
            searchTransaction(criteriaField.getText(), null, "criteria");
        }
    }//GEN-LAST:event_searchBtnActionPerformed

    private void exportExcelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportExcelBtnActionPerformed
        FileOutputStream excelFOU = null;
        BufferedOutputStream excelBOU = null;
        XSSFWorkbook excelJTableExporter = null;

        JFileChooser excelFileChooser = new JFileChooser("F:\\");
        excelFileChooser.setDialogTitle("Save File As");
        FileNameExtensionFilter fnef = new FileNameExtensionFilter("Excel Files", "xlsx");
        excelFileChooser.setFileFilter(fnef);

        int excelChooser = excelFileChooser.showSaveDialog(null);

        if (excelChooser == JFileChooser.APPROVE_OPTION) {

            try {
                excelJTableExporter = new XSSFWorkbook();
                XSSFSheet excelSheet = excelJTableExporter.createSheet("JTable Sheet");

                DefaultTableModel model = (DefaultTableModel) transTable.getModel();

                for (int i = 0; i < model.getRowCount(); i++) {
                    XSSFRow excelRow = excelSheet.createRow(i);
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        XSSFCell excelCell = excelRow.createCell(j);

                        excelCell.setCellValue(model.getValueAt(i, j).toString());
                    }
                }
                excelFOU = new FileOutputStream(excelFileChooser.getSelectedFile() + ".xlsx");
                excelBOU = new BufferedOutputStream(excelFOU);
                excelJTableExporter.write(excelBOU);
                JOptionPane.showMessageDialog(null, "Excel File generated successfully!", "Download Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    if (excelBOU != null) {
                        excelBOU.close();
                    }

                    if (excelFOU != null) {
                        excelFOU.close();
                    }

                    if (excelJTableExporter != null) {
                        excelJTableExporter.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

        }
    }//GEN-LAST:event_exportExcelBtnActionPerformed

    private void exportPdfBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportPdfBtnActionPerformed
        //RELOAD THE TABLE
        DefaultTableModel model = (DefaultTableModel) transTable.getModel();
        model.setRowCount(0);
        showTableData();

        //GENERATE PDF FILE
        String path = "";
        JFileChooser j = new JFileChooser();
        j.setDialogTitle("Save PDF File");
        j.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int x = j.showSaveDialog(this);

        if (x == JFileChooser.APPROVE_OPTION) {
            path = j.getSelectedFile().getPath();
        }

        Document doc = new Document();
        try {
            PdfWriter.getInstance(doc, new FileOutputStream(path + "TransactionsList.pdf"));
            doc.open();
            PdfPTable tbl = new PdfPTable(8); //8 is col num

            //TABLE OPTIONS
            tbl.setWidthPercentage(100);

            //ADDING TABLE HEADER
            tbl.addCell(new Phrase("No.", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));
            tbl.addCell(new Phrase("Client ID", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));
            tbl.addCell(new Phrase("Client Names", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));
            tbl.addCell(new Phrase("Book", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));
            tbl.addCell(new Phrase("Book Category", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));
            tbl.addCell(new Phrase("Type", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));
            tbl.addCell(new Phrase("Transaction Date", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));
            tbl.addCell(new Phrase("Return Date", FontFactory.getFont(FontFactory.HELVETICA, 11, Font.BOLD, new Color(0, 0, 0))));

            for (int i = 0; i < transTable.getRowCount(); i++) {
                tbl.addCell(transTable.getValueAt(i, 0).toString());
                tbl.addCell(transTable.getValueAt(i, 1).toString());
                tbl.addCell(transTable.getValueAt(i, 2).toString());
                tbl.addCell(transTable.getValueAt(i, 3).toString());
                tbl.addCell(transTable.getValueAt(i, 4).toString());
                tbl.addCell(transTable.getValueAt(i, 5).toString());
                tbl.addCell(transTable.getValueAt(i, 6).toString());
                tbl.addCell(transTable.getValueAt(i, 7).toString());
            }
            Paragraph p = new Paragraph();
            p.setIndentationLeft(0);
            p.setIndentationRight(0);
            p.setSpacingAfter(0);
            p.setSpacingBefore(0);
            tbl.setHorizontalAlignment(Element.ALIGN_LEFT);
            p.add(tbl);

            doc.add(p);
            JOptionPane.showMessageDialog(null, "PDF File generated successfully!", "Download Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (FileNotFoundException | DocumentException ex) {
            Logger.getLogger(OperationsPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        doc.close();
    }//GEN-LAST:event_exportPdfBtnActionPerformed

    private void searchDateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchDateBtnActionPerformed
        if (searchDate.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Date field can't be empty!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else {
            searchTransaction("", searchDate.getDate(), "date");
        }
    }//GEN-LAST:event_searchDateBtnActionPerformed

    private void refreshBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshBtnActionPerformed
        refreshTable();
    }//GEN-LAST:event_refreshBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<CategItem> bookField;
    private javax.swing.JComboBox<CategItem> clientField;
    private javax.swing.JTextField criteriaField;
    private javax.swing.JButton exportExcelBtn;
    private javax.swing.JButton exportPdfBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton refreshBtn;
    private com.toedter.calendar.JDateChooser retDate;
    private javax.swing.JButton saveTransBtn;
    private javax.swing.JButton searchBtn;
    private com.toedter.calendar.JDateChooser searchDate;
    private javax.swing.JButton searchDateBtn;
    private javax.swing.JTable transTable;
    private javax.swing.JComboBox<String> typeField;
    // End of variables declaration//GEN-END:variables
}
