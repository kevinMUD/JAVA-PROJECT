package frames;

import comboBox.CategItem;
import helpers.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import mapping.*;
import org.hibernate.*;

public class BooksPage extends javax.swing.JInternalFrame {

    public BooksPage() {
        initComponents();
        showCategTableData();
        showBookCategs();
        showBooksTableData();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        saveCategBtn = new javax.swing.JToggleButton();
        categNameField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        codeField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        categTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        saveBookBtn = new javax.swing.JToggleButton();
        authorField = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        pHouse = new javax.swing.JTextField();
        bookId = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        pagesField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        categField = new javax.swing.JComboBox<>();
        titleField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        pDate = new com.toedter.calendar.JDateChooser();
        jScrollPane2 = new javax.swing.JScrollPane();
        booksTable = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Books & Book Categories");
        setToolTipText("");
        setPreferredSize(new java.awt.Dimension(1018, 786));

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Add Category", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Open Sans", 1, 12))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel1.setText("Code");

        saveCategBtn.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        saveCategBtn.setText("Save Category");
        saveCategBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveCategBtnActionPerformed(evt);
            }
        });

        categNameField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        categNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categNameFieldActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel2.setText("Name");

        codeField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        codeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codeFieldActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(categNameField)
                            .addComponent(codeField, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(saveCategBtn)
                        .addGap(39, 39, 39)))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(codeField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(categNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addComponent(saveCategBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        categTable.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        categTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Code", "Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(categTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(346, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Book Category", jPanel2);

        jPanel5.setPreferredSize(new java.awt.Dimension(997, 689));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Add Book", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Open Sans", 1, 12))); // NOI18N

        jLabel9.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel9.setText("Title");

        saveBookBtn.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        saveBookBtn.setText("Save Book");
        saveBookBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBookBtnActionPerformed(evt);
            }
        });

        authorField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        authorField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authorFieldActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel11.setText("Category");

        pHouse.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        pHouse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pHouseActionPerformed(evt);
            }
        });

        bookId.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        bookId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookIdActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel8.setText("Publishing House");

        jLabel3.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel3.setText("Book Id");

        jLabel4.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel4.setText("Author");

        pagesField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        pagesField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pagesFieldActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel10.setText("Pages");

        categField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        categField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categFieldActionPerformed(evt);
            }
        });

        titleField.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        titleField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                titleFieldActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Open Sans", 1, 12)); // NOI18N
        jLabel7.setText("Published Date");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(saveBookBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(70, 70, 70)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(authorField, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bookId, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(pDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pHouse, javax.swing.GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE))))
                        .addGap(62, 62, 62)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))))
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(titleField)
                        .addComponent(pagesField, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(categField, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(bookId, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(authorField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(pagesField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(pHouse, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(categField, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel7))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(pDate, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(saveBookBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        booksTable.setFont(new java.awt.Font("Open Sans", 0, 12)); // NOI18N
        booksTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Title", "Category", "Author", "Pub. House", "Pub. Date", "Pages", "Available"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(booksTable);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(121, 121, 121)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(144, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47))
        );

        jScrollPane3.setViewportView(jPanel5);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 997, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 711, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Book", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void showBookCategs() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            List result = session.createQuery("FROM BookCategory").list();

            CategItem dItem = new CategItem("DEFAULT", "Choose");
            categField.addItem(dItem);
            for (Iterator iterator = result.iterator(); iterator.hasNext();) {
                BookCategory bCateg = (BookCategory) iterator.next();
                String name = bCateg.getName();
                String code = bCateg.getCode();
                CategItem cItem = new CategItem(code, name);

                categField.addItem(cItem);
            }
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    public void showCategTableData() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            List result = session.createQuery("FROM BookCategory").list();
            DefaultTableModel model = (DefaultTableModel) categTable.getModel();
            Object[] row = new Object[2];

            for (Iterator iterator = result.iterator(); iterator.hasNext();) {
                BookCategory bCateg = (BookCategory) iterator.next();

                row[0] = bCateg.getCode();
                row[1] = bCateg.getName();
                model.addRow(row);
            }

            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    public void saveBookCateg() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            BookCategory bCateg = new BookCategory();

            //CHECK DUPLICATES BEFORE INSERTING
            DuplicatesCheck dCheck = new DuplicatesCheck();
            int check = dCheck.checkDuplicates(codeField.getText(), "BookCategory");
            if (check > 0) {
                JOptionPane.showMessageDialog(null, "Category with same id already exists!", "Duplicates Error", JOptionPane.ERROR_MESSAGE);
            } else {
                //PASSING DATA TO THE MAPPING FILE
                bCateg.setCode(codeField.getText());
                bCateg.setName(categNameField.getText());
                session.save(bCateg);
                tx.commit();

                //DISPLAY SUCCESS MSG
                JOptionPane.showMessageDialog(null, "Saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                //UPDATING COMBO BOX
                CategItem cItem = new CategItem(codeField.getText(), categNameField.getText());
                categField.addItem(cItem);

                //UPDATE CATEG TABLE
                DefaultTableModel model = (DefaultTableModel) categTable.getModel();
                model.setRowCount(0);
                showCategTableData();

                //CLEAR FORM
                codeField.setText("");
                categNameField.setText("");
            }
        } catch (HibernateException ex) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, ex, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    //POPULATE THE BOOKS TABLE
    public void showBooksTableData() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            List result = session.createQuery("FROM Books").list();
            DefaultTableModel model = (DefaultTableModel) booksTable.getModel();
            Object[] row = new Object[8];

            for (Iterator iterator = result.iterator(); iterator.hasNext();) {
                Books book = (Books) iterator.next();

                row[0] = book.getBookid();
                row[1] = book.getTitle();
                BookCategory categ = book.getCategory();
                row[2] = categ.getName();
                row[3] = book.getAuthor();
                row[4] = book.getPubhouse();
                row[5] = book.getPubdate();
                row[6] = book.getPages();
                row[7] = book.getAvailable();
                model.addRow(row);
            }

            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    //ADDING A NEW BOOK
    public void saveBook() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();
            Books book = new Books();

            //CHECK DUPLICATES BEFORE INSERTING
            DuplicatesCheck dCheck = new DuplicatesCheck();
            int check = dCheck.checkDuplicates(bookId.getText(), "Books");
            if (check > 0) {
                JOptionPane.showMessageDialog(null, "Book with the same id already exists!", "Duplicates Error", JOptionPane.ERROR_MESSAGE);
            } else {
                //PASSING DATA TO THE MAPPING FILE
                book.setBookid(bookId.getText());
                book.setTitle(titleField.getText());
                book.setAuthor(authorField.getText());

                //CONVERTING PAGES TO INT TYPE
                String pages = pagesField.getText();
                book.setPages(Integer.parseInt(pages));

                //GETTING THE SELECTED CATEGORY
                String hql = "FROM BookCategory WHERE code= :id";
                //CREATING A HIBERNATE QUERY AND ADD THE RESULT TO A LIST
                Query query = session.createQuery(hql);
                CategItem item = (CategItem) categField.getSelectedItem();
                query.setParameter("id", item.id);
                List result = query.list();
                Iterator iterator = result.iterator();
                iterator.hasNext();
                BookCategory cResult = (BookCategory) iterator.next();
                //ADDING THE CATEGORY
                book.setCategory(cResult);
                book.setPubhouse(pHouse.getText());
                book.setPubdate(pDate.getDate());
                book.setAvailable(true);
                session.save(book);
                tx.commit();

                //DISPLAY SUCCESS MSG
                JOptionPane.showMessageDialog(null, "Saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                //UPDATE BOOKS TABLE
                DefaultTableModel model = (DefaultTableModel) booksTable.getModel();
                model.setRowCount(0);
                showBooksTableData();

                //CLEAR FORM
                bookId.setText("");
                titleField.setText("");
                authorField.setText("");
                pagesField.setText("");
                categField.removeAllItems();
                showBookCategs();
                pHouse.setText("");
                pDate.setDate(null);
            }
        } catch (HibernateException e) {
            if (tx != null) {
                tx.rollback();
            }
            JOptionPane.showMessageDialog(null, e, "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            session.close();
        }
    }

    private void saveCategBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveCategBtnActionPerformed
        //VALIDATIONS FOR FIELDS
        if (codeField.getText().equals("") || categNameField.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Please fill all fields!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else if (codeField.getText().length() != 3) {
            JOptionPane.showMessageDialog(null, "Category Id must only contain 3 characters!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else {
            saveBookCateg();
        }
    }//GEN-LAST:event_saveCategBtnActionPerformed

    private void categNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categNameFieldActionPerformed

    }//GEN-LAST:event_categNameFieldActionPerformed

    private void codeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codeFieldActionPerformed

    }//GEN-LAST:event_codeFieldActionPerformed

    private void saveBookBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBookBtnActionPerformed
        //VALIDATIONS FOR FIELDS
        if (bookId.getText().equals("")
                || titleField.getText().equals("")
                || authorField.getText().equals("")
                || pHouse.getText().equals("")
                || pagesField.getText().equals("")
                || pDate.getDate() == null
                || categField.getSelectedItem().toString().equals("Choose")) {
            JOptionPane.showMessageDialog(null, "Please fill all fields!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else if (bookId.getText().length() != 5) {
            JOptionPane.showMessageDialog(null, "Book Id must only contain 5 characters!", "Validation Error", JOptionPane.WARNING_MESSAGE);
        } else {
            saveBook();
        }
    }//GEN-LAST:event_saveBookBtnActionPerformed

    private void authorFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authorFieldActionPerformed

    }//GEN-LAST:event_authorFieldActionPerformed

    private void pHouseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pHouseActionPerformed

    }//GEN-LAST:event_pHouseActionPerformed

    private void bookIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookIdActionPerformed

    }//GEN-LAST:event_bookIdActionPerformed

    private void pagesFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pagesFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pagesFieldActionPerformed

    private void categFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_categFieldActionPerformed

    private void titleFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_titleFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_titleFieldActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField authorField;
    private javax.swing.JTextField bookId;
    private javax.swing.JTable booksTable;
    private javax.swing.JComboBox<CategItem> categField;
    private javax.swing.JTextField categNameField;
    private javax.swing.JTable categTable;
    private javax.swing.JTextField codeField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private com.toedter.calendar.JDateChooser pDate;
    private javax.swing.JTextField pHouse;
    private javax.swing.JTextField pagesField;
    private javax.swing.JToggleButton saveBookBtn;
    private javax.swing.JToggleButton saveCategBtn;
    private javax.swing.JTextField titleField;
    // End of variables declaration//GEN-END:variables
}
