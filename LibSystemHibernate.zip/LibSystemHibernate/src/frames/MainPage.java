package frames;

import auth.LoginForm;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;

public class MainPage extends javax.swing.JFrame {

    public MainPage() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        logoutMenu = new javax.swing.JMenuItem();
        clientMenu = new javax.swing.JMenu();
        clientMenuItem = new javax.swing.JMenuItem();
        booksMenu = new javax.swing.JMenu();
        bookMenuItem = new javax.swing.JMenuItem();
        operationsMenu = new javax.swing.JMenu();
        operMenuItem = new javax.swing.JMenuItem();

        setTitle("Library System - Homepage");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("lib1.png")));

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");
        fileMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileMenuActionPerformed(evt);
            }
        });

        logoutMenu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        logoutMenu.setMnemonic('g');
        logoutMenu.setText("Logout");
        logoutMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutMenuActionPerformed(evt);
            }
        });
        fileMenu.add(logoutMenu);

        menuBar.add(fileMenu);

        clientMenu.setMnemonic('c');
        clientMenu.setText("Client");
        clientMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientMenuActionPerformed(evt);
            }
        });

        clientMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        clientMenuItem.setMnemonic('l');
        clientMenuItem.setText("View Clients");
        clientMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientMenuItemActionPerformed(evt);
            }
        });
        clientMenu.add(clientMenuItem);

        menuBar.add(clientMenu);

        booksMenu.setMnemonic('b');
        booksMenu.setText("Books");
        booksMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksMenuActionPerformed(evt);
            }
        });

        bookMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        bookMenuItem.setMnemonic('k');
        bookMenuItem.setText("View Books");
        bookMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookMenuItemActionPerformed(evt);
            }
        });
        booksMenu.add(bookMenuItem);

        menuBar.add(booksMenu);

        operationsMenu.setMnemonic('o');
        operationsMenu.setText("Operations");
        operationsMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                operationsMenuActionPerformed(evt);
            }
        });

        operMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        operMenuItem.setMnemonic('t');
        operMenuItem.setText(" View Operations");
        operMenuItem.setToolTipText("");
        operMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                operMenuItemActionPerformed(evt);
            }
        });
        operationsMenu.add(operMenuItem);

        menuBar.add(operationsMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1090, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    private void logoutMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutMenuActionPerformed
        systemExit();
        LoginForm login = new LoginForm();
        login.setVisible(true);
    }//GEN-LAST:event_logoutMenuActionPerformed

    private void fileMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileMenuActionPerformed

    }//GEN-LAST:event_fileMenuActionPerformed

    private void clientMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientMenuItemActionPerformed
        ClientsPage cPage = new ClientsPage();
        desktopPane.add(cPage);
        cPage.setVisible(true);
    }//GEN-LAST:event_clientMenuItemActionPerformed

    private void clientMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientMenuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_clientMenuActionPerformed

    private void bookMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookMenuItemActionPerformed
        BooksPage bPage = new BooksPage();
        desktopPane.add(bPage);
        bPage.setVisible(true);
    }//GEN-LAST:event_bookMenuItemActionPerformed

    private void booksMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksMenuActionPerformed

    }//GEN-LAST:event_booksMenuActionPerformed

    private void operMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_operMenuItemActionPerformed
        OperationsPage oPage = new OperationsPage();
        desktopPane.add(oPage);
        oPage.setVisible(true);
    }//GEN-LAST:event_operMenuItemActionPerformed

    private void operationsMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_operationsMenuActionPerformed

    }//GEN-LAST:event_operationsMenuActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem bookMenuItem;
    private javax.swing.JMenu booksMenu;
    private javax.swing.JMenu clientMenu;
    private javax.swing.JMenuItem clientMenuItem;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenuItem logoutMenu;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem operMenuItem;
    private javax.swing.JMenu operationsMenu;
    // End of variables declaration//GEN-END:variables
    public void systemExit() {
        WindowEvent winClosing = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosing);
    }
}
