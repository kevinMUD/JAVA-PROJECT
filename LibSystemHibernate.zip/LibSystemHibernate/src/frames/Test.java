package frames;

import java.util.*;
import mapping.*;
import org.hibernate.*;

public class Test {

    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Books elt = new Books();
            elt.setBookid("BK001");
            elt.setTitle("Prey");
            elt.setAuthor("Micahel Crichton");
            elt.setPubhouse("Editions Bakame");
            elt.setPages(245);
            elt.setAvailable(true);
            Date dt = new Date();
            elt.setPubdate(dt);
            
            String hql = "FROM BookCategory WHERE code= :id";

            //CREATING A HIBERNATE QUERY AND ADD THE RESULT TO A LIST
            Query query = session.createQuery(hql);
            query.setParameter("id", "001");
            List result = query.list();
            Iterator iterator = result.iterator();
            iterator.hasNext();
            BookCategory cResult = (BookCategory) iterator.next();
            
            elt.setCategory(cResult);
            session.save(elt);
            tx.commit();
            System.out.println("Success!");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
