package comboBox;

public class CategItem {

    public String id;
    public String name;

    public CategItem(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
