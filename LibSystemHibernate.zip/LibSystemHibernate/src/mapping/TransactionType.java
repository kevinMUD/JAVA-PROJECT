package mapping;

public enum TransactionType {
    BORROW, RETURN
}
