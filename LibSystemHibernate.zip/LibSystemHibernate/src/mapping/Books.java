package mapping;

import java.util.*;
import javax.persistence.*;

@Entity
@Table(name = "books")
public class Books {

    @Id
    @Column(length = 5)
    private String bookid;
    private String title;
    private String author;
    private String pubhouse;
    private int pages;
    private Boolean available;
    @Temporal(TemporalType.DATE)
    private Date pubdate;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "category")
    private BookCategory category;

    public Books() {
    }

    public Books(String bookid, String title, String author, String pubhouse, int pages, Boolean available, Date pubdate, BookCategory category) {
        this.bookid = bookid;
        this.title = title;
        this.author = author;
        this.pubhouse = pubhouse;
        this.pages = pages;
        this.available = available;
        this.pubdate = pubdate;
        this.category = category;
    }

    public String getBookid() {
        return bookid;
    }

    public void setBookid(String bookid) {
        this.bookid = bookid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPubhouse() {
        return pubhouse;
    }

    public void setPubhouse(String pubhouse) {
        this.pubhouse = pubhouse;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public Date getPubdate() {
        return pubdate;
    }

    public void setPubdate(Date pubdate) {
        this.pubdate = pubdate;
    }

    public BookCategory getCategory() {
        return category;
    }

    public void setCategory(BookCategory category) {
        this.category = category;
    }
    
}
