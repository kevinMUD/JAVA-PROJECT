package mapping;

public enum ClientCategory {
    STAFF, STUDENT
}
