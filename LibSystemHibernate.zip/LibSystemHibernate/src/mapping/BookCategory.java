package mapping;

import javax.persistence.*;

@Entity
@Table(name = "book_category")
public class BookCategory {

    @Id
    @Column(length = 3)
    private String code;
    private String name;

    public BookCategory(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public BookCategory() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
