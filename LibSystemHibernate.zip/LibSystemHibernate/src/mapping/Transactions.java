package mapping;

import java.util.*;
import javax.persistence.*;

@Entity
@Table(name = "transactions")
public class Transactions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
    @Temporal(TemporalType.DATE)
    private Date transdate;
    @Temporal(TemporalType.DATE)
    private Date retdate;
    @Enumerated(EnumType.STRING)
    @Column(name="type")
    private TransactionType type;
    
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="client")
    private Clients client;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="book")
    private Books book;

    public Transactions() {
    }

    public Transactions(int id, Date transdate, Date retdate, TransactionType type, Clients client, Books book) {
        this.id = id;
        this.transdate = transdate;
        this.retdate = retdate;
        this.type = type;
        this.client = client;
        this.book = book;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTransdate() {
        return transdate;
    }

    public void setTransdate(Date transdate) {
        this.transdate = transdate;
    }

    public Date getRetdate() {
        return retdate;
    }

    public void setRetdate(Date retdate) {
        this.retdate = retdate;
    }

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public Clients getClient() {
        return client;
    }

    public void setClient(Clients client) {
        this.client = client;
    }

    public Books getBook() {
        return book;
    }

    public void setBook(Books book) {
        this.book = book;
    }
    
}
