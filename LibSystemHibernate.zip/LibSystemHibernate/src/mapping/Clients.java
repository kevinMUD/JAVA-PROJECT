package mapping;

import javax.persistence.*;

@Entity
@Table(name = "clients")
public class Clients {

    @Id
    @Column(length = 5)
    private String regid;
    private String firstname;
    private String lastname;
    private String email;
    @Column(length = 15)
    private String phone;
    @Enumerated(EnumType.STRING)
    @Column(name="category")
    private ClientCategory category;
    private byte[] photo;

    public Clients() {
    }

    public Clients(String regid, String firstname, String lastname, String email, String phone, ClientCategory category, byte[] photo) {
        this.regid = regid;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.phone = phone;
        this.category = category;
        this.photo = photo;
    }

    public String getRegid() {
        return regid;
    }

    public void setRegid(String regid) {
        this.regid = regid;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public ClientCategory getCategory() {
        return category;
    }

    public void setCategory(ClientCategory category) {
        this.category = category;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }
    
}
