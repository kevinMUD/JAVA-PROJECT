/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.List;
import model.Book;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author hp
 */
public class BookDAO {
    static Session session = null;
    public static void saveBook(Book book)
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(book);
        tx.commit();
        session.close();
    }
     public static Book getBook(String column, String value)
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Query hql = session.createQuery("from Book where"+column+"="+"'"+value+"'");
        Book book = (Book)hql.uniqueResult();
        tx.commit();
        session.close();
        return book;
    }
    public static List<Book> allBooks()
    {
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Query hql = session.createQuery("from Book");
        List<Book> books = hql.list();
        tx.commit();
        session.close();
        return books;
    }
}
