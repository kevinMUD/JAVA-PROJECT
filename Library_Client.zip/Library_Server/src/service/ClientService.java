/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import DAO.ClientDAO;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.Client;

/**
 *
 * @author hp
 */
public class ClientService extends UnicastRemoteObject implements ClientServiceInterface {

    public ClientService() throws RemoteException {
        super();
    }
    
    @Override
    public boolean saveClient(Client client) throws RemoteException {
        ClientDAO.saveClient(client);
        return true;
    }

    @Override
    public Client getClient(String column, String value) throws RemoteException {
        Client client = ClientDAO.getClient(column, value);
        return client; 
    }

    @Override
    public List<Client> allClients() throws RemoteException {
        List<Client> clients = ClientDAO.allClients();
        return clients;
    }
    
}
