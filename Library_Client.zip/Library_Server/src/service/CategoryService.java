/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import DAO.CategoryDAO;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import model.BookCategory;

/**
 *
 * @author hp
 */
public class CategoryService extends UnicastRemoteObject implements CategoryServiceInterface{

    public CategoryService() throws RemoteException {
    }
    
    
    @Override
    public boolean saveCategory(BookCategory cat) throws RemoteException {
        CategoryDAO.saveCategory(cat);
        return true;
    }

    @Override
    public List<BookCategory> allCategory(BookCategory cat) throws RemoteException {
        List<BookCategory> categories = CategoryDAO.allCategory();
        return categories;
    }
    
}
