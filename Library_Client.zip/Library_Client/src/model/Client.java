/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author hp
 */
public class Client implements Serializable {
    private String regId;
    private String firstName;
    private String LastName;
    private String phoneNumber;
    private String email;
    private byte[] photo;
    private ClientCategory category;

    public Client() {
    }

    
    public Client(String regId, String firstName, String LastName, String phoneNumber, String email, ClientCategory category, byte[] photo) {
        this.regId = regId;
        this.firstName = firstName;
        this.LastName = LastName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.photo = photo;
        this.category = category;
    }

    public String getRegId() {
        return regId;
    }

    public void setRegId(String regId) {
        this.regId = regId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    public ClientCategory getCategory() {
        return category;
    }

    public void setCategory(ClientCategory category) {
        this.category = category;
    }
    
    
}
    
