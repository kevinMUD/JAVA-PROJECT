
package service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import model.Citizen;

/**
 *
 * @author jeremie
 */
public interface CitizenInterface extends Remote{
    // method signature
    public String registerCitizen(Citizen citizen) throws RemoteException;
    public String updateCitizen(Citizen citizen) throws RemoteException;
    public String deleteCitizen(Citizen citizen) throws RemoteException;
    public List<Citizen> getAllCitizen() throws RemoteException;
    public Citizen getCitizenById(Citizen citizen) throws RemoteException;
}
