
package dao;

import java.util.List;
import model.Citizen;
import org.hibernate.*;

/**
 *
 * @author jeremie
 */
public class CitizenDao {
    
    // Create-operation
    public String registerCitizen(Citizen citizen){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        //create transaction
        Transaction tr = ss.beginTransaction();
        // save citizen
        ss.save(citizen);
        tr.commit();
        ss.close();
        return "Data Saved Successful";
    }
    
    // Update-operation
    public String updateCitizen(Citizen citizen){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        //create transaction
        Transaction tr = ss.beginTransaction();
        // save citizen
        Citizen cit = getCitizenById(citizen);
        if(cit != null){
            cit.setIs_vaccinate(citizen.isIs_vaccinate());
            ss.update(cit);
        }
        tr.commit();
        ss.close();
        return "Data updated Successful";
    }
    
    // delete-operation
    public String deleteCitizen(Citizen citizen){
        // create session
        Session ss = HibernateUtil.getSessionFactory().openSession();
        //create transaction
        Transaction tr = ss.beginTransaction();
        // save citizen
        ss.delete(citizen);
        tr.commit();
        ss.close();
        return "Citizen Deleted Successful";
    }
    
    // read data from db
    public List<Citizen> allCitizen(){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Citizen> citizensList = ss.createQuery("select cit from Citizen cit").list();
        ss.close();
        return citizensList;
    }
    
    // search Citizen By Id
    public Citizen getCitizenById(Citizen citizen){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Citizen cit = (Citizen)ss.get(Citizen.class, citizen.getCitizen_id());
        ss.close();
        return cit;
    }
}
